package com.tealium.gawebviewdemo;

import android.app.Application;

/**
 * Created by craigrouse on 22/11/2016.
 */

public class GAApplication extends Application {

    public static String gaSessionId = null;
    @Override
    public void onCreate () {
        super.onCreate();
        TealiumHelper.initialize(this);
    }

}
