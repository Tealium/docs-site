package com.tealium.gawebviewdemo;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.widget.Toast;

import com.tealium.internal.listeners.WebViewCreatedListener;
import com.tealium.library.Tealium;
import com.tealium.internal.tagbridge.RemoteCommand;

import org.json.JSONObject;

import java.util.Map;

/**
 * Created by craigrouse on 22/11/2016.
 */

public final class TealiumHelper {

    public static final String TEALIUM_INSTANCENAME = "test";

    @SuppressLint("NewApi")
    public static void initialize(final Application application) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT && BuildConfig.DEBUG) {
            // To connect to WebView if Tag Management is enabled
            WebView.setWebContentsDebuggingEnabled(true);
        }

        Tealium.Config config = Tealium.Config.create(application, "services-crouse", "mobile-ga-demo", "dev");
        config.getEventListeners().add(createCookieEnablerListener());
        Tealium inst = Tealium.createInstance(TEALIUM_INSTANCENAME, config);
        inst.addRemoteCommand(new RemoteCommand("syncGASession", "Syncs the GA Session ID") {
            @Override
            protected void onInvoke(Response response) throws Exception {
                JSONObject resp = response.getRequestPayload();
                GAApplication.gaSessionId = resp.optString("sessionId", null);
            }
        });
    }

    // enable cookies in the Android webview
    private static WebViewCreatedListener createCookieEnablerListener() {
        return new WebViewCreatedListener() {
            @Override
            public void onWebViewCreated(WebView webView) {
                final CookieManager mgr = CookieManager.getInstance();

                // Accept all cookies
                mgr.setAcceptCookie(true);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    mgr.setAcceptThirdPartyCookies(webView, true);
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR1) {
                    CookieManager.setAcceptFileSchemeCookies(true);
                }
            }

            @Override
            public String toString() {
                return "EnableCookieWebViewCreatedListener";
            }
        };
    }

    public static void trackEvent(String eventName, Map<String, ?> data) {
        final Tealium instance = Tealium.getInstance(TEALIUM_INSTANCENAME);
        Log.v("TealiumHelper","Inside trackEvent function");
        // Log.v("Teal Instance", instance.toString());
        // instance can be remotely destroyed by publish settings
        if(instance != null) {
            instance.trackEvent(eventName, data);
        }
    }

    public static void trackView(String viewName, Map<String, ?> data) {
        final Tealium instance = Tealium.getInstance(TEALIUM_INSTANCENAME);

        // instance can be remotely destroyed by publish settings
        if(instance != null) {
            instance.trackView(viewName, data);
        }
    }

}
